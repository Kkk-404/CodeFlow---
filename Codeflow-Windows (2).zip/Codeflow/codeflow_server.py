#!/usr/bin/env python3
"""Loopback-only static server for Codeflow, with a restrictive Python-worker CSP."""
from __future__ import annotations

import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
WORKER_CSP = (
    "default-src 'none'; "
    "script-src 'self' 'wasm-unsafe-eval'; "
    "connect-src 'self'; "
    "worker-src 'none'; "
    "child-src 'none'; "
    "object-src 'none'; "
    "base-uri 'none'; "
    "form-action 'none'"
)


class CodeflowRequestHandler(SimpleHTTPRequestHandler):
    """Serve package files and put a browser-enforced policy on the Python worker."""

    def send_head(self):
        # Loopback binding alone is not enough against DNS-rebinding Host headers.
        host = (self.headers.get("Host") or "").lower().rstrip(".")
        port = str(self.server.server_port)
        allowed_hosts = {f"127.0.0.1:{port}", f"localhost:{port}"}
        if host not in allowed_hosts:
            self.send_error(421, "Invalid Host header")
            return None
        return super().send_head()

    def end_headers(self) -> None:
        path = urlsplit(self.path).path
        if path == "/python-runner-worker.js":
            self.send_header("Content-Security-Policy", WORKER_CSP)
        self.send_header("X-Content-Type-Options", "nosniff")
        super().end_headers()


def main() -> None:
    parser = argparse.ArgumentParser(description="Serve Codeflow on this computer only.")
    parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    handler = partial(CodeflowRequestHandler, directory=str(ROOT))
    server = ThreadingHTTPServer(("127.0.0.1", args.port), handler)
    print(f"Codeflow is available at http://127.0.0.1:{args.port}/index.html")
    print("Python worker CSP is active; press Ctrl+C to stop the server.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping Codeflow server.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
